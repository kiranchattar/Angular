import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from 'src/app/data.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { MatPaginator, MatTableDataSource } from '@angular/material';
export interface ProductInterface {
  responseLength: any;
}
@Component({
  selector: 'app-cash-voucher',
  templateUrl: './cash-voucher.component.html',
  styleUrls: ['./cash-voucher.component.scss']
})
export class CashVoucherComponent implements OnInit {
  displayedColumns: string[] = ['position', 'voucher_no', 'pay_to', 'date', 'amount', 'type', 'action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private service: DataService, private router: Router) {}
  responseLength: any;
  NewVoucher = false;
  voucher;
  pay_to = '';
  date = '';
  isProd = true;
  particulars = '';
  amount = 0 ;
  total_amount = 0;
  productList = [];
  index = 0;
  voucherdetail;

  ngOnInit() {
    this.getvoucher();
  }
  closevoucher(formdata) {
    formdata.reset();
    this.productList = [];
    this.isProd = true;
    this.index = 0;
    this.NewVoucher = false;
    this.getvoucher();
  }
  getvoucher() {
    this.service.get('voucher.php?type=getvoucher').subscribe((response: any) => {
      this.voucher = response;
      this.voucher = new MatTableDataSource(response);
      this.voucher.response = response;
      this.responseLength = response.length;
      this.voucher.paginator = this.paginator;
    });
  }
  VoucherAction(voucher_no, value) {
    if (value === 'delete') {
      Swal.fire({
        title: 'Are you sure?',
        text: 'You won\'t be able to revert this!',
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.value) {
          this.service.get('voucher.php?type=deletevoucher&voucher_no=' + voucher_no).subscribe (response => {
        if (response['status'] === 'success') {
          this.getvoucher();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
          });
          Toast.fire({
            type: 'success',
            title: 'Cash Voucher has been deleted.'
          });
        }
      });
        }
      });
    } else if (value === 'print') {
      window.open(this.service.url + 'voucher.php?type=printvoucher&voucher_no=' + voucher_no , '_blank');
    }
  }
  addProduct() {
    if (this.particulars.length > 0 && this.amount > 0 ) {
      const tempList = {};
      this.isProd = false;
      tempList['particulars'] = this.particulars;
      tempList['amount'] = this.amount;
      this.total_amount += parseFloat((+tempList['amount']).toFixed(2));
      this.productList[this.index] = tempList;
      this.index++;
      this.particulars = '';
      this.amount = 0;
    }
  }
  addvoucher (formdata) {
    const temp = formdata.value;
    temp['products'] = this.productList;
    this.service.post('voucher.php?type=addvoucher', JSON.stringify(temp)).subscribe(response => {
      if (response['status'] === 'success') {
        this.closevoucher(formdata);
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
          });
          Toast.fire({
            type: 'success',
            title: 'Voucher Generated Succesfully.'
          });
      } else {
        alert('check details');
      }
    },
    (error: Response) => {
      if (error.status === 400) {
        alert('An error has occurred.');
      } else {
        alert('An error has occurred, http status:' + error.status);
      }
    });
  }
}


